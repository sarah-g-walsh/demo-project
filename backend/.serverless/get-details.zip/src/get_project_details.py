import os
import json
import boto3


def get_details(event, context):
    """
    Returns all project details from a DynamoDB table
    """

    try:
        # query the dynamo table
        dynamo_client = boto3.client("dynamodb")
        table_name = os.getenv("PROJECT_TABLE", None)
        items = dynamo_client.scan(TableName=table_name).get("Items")


        # return the items as a json object
        response = json.dumps(
            {
                "items": items,
                "statusCode": 200,
            }
        )

    # return an error message as a JSON object if there is an error
    except:
        response = json.dumps({"message": "An error has occurred.", "statusCode": 500})

    return response
